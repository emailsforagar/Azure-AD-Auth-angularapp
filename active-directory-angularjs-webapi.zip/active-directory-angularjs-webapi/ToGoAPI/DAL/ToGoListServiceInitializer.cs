﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ToGoAPI.DAL
{
    public class ToGoListServiceInitializer : System.Data.Entity.DropCreateDatabaseIfModelChanges<ToGoListServiceContext>
    {
    }
}
