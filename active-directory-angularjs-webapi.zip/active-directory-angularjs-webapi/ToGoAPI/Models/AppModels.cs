﻿namespace ToGoAPI.Models
{
    public class ToGo
    {
        public int ID { get; set; }
        public string Description { get; set; }
        public string Owner { get; set; }
    }
}
